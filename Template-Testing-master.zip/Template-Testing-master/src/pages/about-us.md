---
templateKey: about-page
title: About Us
slug: ""
seoTitle: About Us
seoDescription: I was searching for reviews about tech products I found that
  most of the websites weren't providing useful thats when I got the idea of
  this website.
---

## How it all Happened

While I was searching for reviews about tech products I found that most of the websites weren’t providing useful that’s when I got the idea of [[siteName]]. I believed that I could write better reviews in a more professional way.

If you wish to know which product fits your needs best, this blog will be of big help to you.

There are a lot of people who consider whatever product their friends, spouse, family members, or teachers suggest to them with. Not a lot of people have leisure time on their hands to do a little research themselves and check out several reviews. Believe me, it takes a lot of time to search for a product online.

## [[siteLink]]

The major purpose of **[[siteLink]]** is to deliver honest and reviews about all the technologic products in the world by ranking them from 1-10 – the top ten list.

My idea of this blog is for it to be the only place where people come to when they are having second thoughts about finding good products that meet their needs. Regardless of the name of the product, if it’s a tech product, we got you covered.

Make sure to read carefully and always drop a comment.

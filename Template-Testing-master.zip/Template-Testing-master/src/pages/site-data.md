---
templateKey: site-data
title: Gaming Dairy
logoSmall: /img/logo.png
logoLarge: /img/logo-large.png
faviconSmall: /img/favicon-16x16.jpg
faviconLarge: /img/favicon-32x32.jpg
disqus: protechreviewer-com
facebook: ""
youtube: https://www.youtube.com/sitetitle
twitter: https://www.twitter.com/sitetitle
number: ""
dmca: true
dmcaLink: https://images.dmca.com/Badges/dmca_protected_sml_120n.png?ID=a402cd6b-f9a0-4bd6-9221-3880bf2baff4
linkType: true
cookies:
  enabled: true
  message: This website uses cookies to enhance the user experience.
colors:
  btnColor: "#ffffff"
  headerTextColor: "#ffffff"
  btnBackground: "#5899fd"
  background: "#222831"
  btnHoverBackground: "#91bbff"
  navbarShadow: "#828282"
  textColor: "#ffffff"
  blockBackground: "#3c4758"
  headerBackground: "#71757a"
topNav:
  - title: Learning Guides
    link: /learning-guides/
    child:
      - title: Miscellaneous
        link: "#"
        child:
          - title: Test Post
            link: /sample-post-buying/
          - title: Test Post
            link: /sample-post-buying/
      - title: Peripherals
        link: "#"
        child:
          - title: Test Post
            link: /sample-post-buying/
          - title: Test Post
            link: /sample-post-buying/
  - title: Buying Guides
    link: /buying-guides/
    child:
      - title: Sample Post News
        link: /sample-post-buying/
        child: []
      - title: Sample Post
        link: /sample-post-buying/
  - title: News
    link: /news/
  - title: Reviews
    link: /reviews/
footerNav:
  - title: About Us
    link: /about-us/
  - title: Contact Us
    link: /contact-us/
  - link: /affiliate-disclosure/
    title: Affiliate Disclosure
  - title: Terms of Service
    link: /terms-of-service/
  - title: Privacy Policy
    link: /privacy-policy/
  - title: Sitemap
    link: /sitemap.xml
nofollow:
  - /news/
noindex:
  - /contact-us/thanks/
sitemap:
  - /contact-us/thanks/
---
